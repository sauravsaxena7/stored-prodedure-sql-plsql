
USE [HaProductsUAT]
GO
/****** Object:  StoredProcedure [dbo].[opsUspPlanListByClientList]    Script Date: 1/10/2024 12:07:45 PM ******/

--SELECT TOP 100 * FROM OPDPartnerDetails ORDER BY 1 DESC

--SELECT CorporatePlanId FROM CorporatePlan where clientId=292 and isActive='Y'

--SELECT * FROM OPDPartnerDetails where PlanId in (SELECT CorporatePlanId FROM CorporatePlan where clientId=292 and isActive='Y') and IsActive='Y'
  
  --EXEC [opsUspOPDPartnerListByClientid] 292
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER Procedure [dbo].[opsUspOPDPartnerListByClientid]
@clientIds varchar(100)
As
Begin
Select OP.OPDPartnerDetailsId,OP.PartnerName 
from OPDPartnerDetails OP 
join CorporatePlan CP ON CP.CorporatePlanId=OP.PlanId
join Client C on C.ClientId=CP.ClientId
where OP.IsActive = 'Y' 
and CP.IsActive='Y'
and C.ClientId in (select * from SplitString(@clientIds,',')) 
UNION
Select OP.OPDPartnerDetailsId,OP.PartnerName 
from OPDPartnerDetails OP 
join CNPlanDetails CN ON CN.CNPlanDetailsId=OP.CNPlanDetailsId
join Client C on C.ClientId=CN.ClientId
where OP.IsActive = 'Y' 
and CN.ActiveStatus='Y'
and C.ClientId in (select * from SplitString(@clientIds,',')) 
END