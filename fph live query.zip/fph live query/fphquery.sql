SELECT * FROM Userlogin WHERE  UserName='fp@gmail.com'
SELECT * FROM Member where UserLoginId=535124

SELECT * FROM Member where MemberId=531859

SELECT * FROM UserPlanDetails where MemberId = 531859

--UserPlanDetailsId=960

SELECT * FROM MemberPlanBucket Where UserPlanDetailsId=960
SELECT * FROM MemberPLanBucketsDetails where MemberPlanBucketId IN (1118,
1119,
1120)